import axios from 'axios';

const BASE_URL = 'http://172.16.85.27:5000'; // Base URL API

const BPJSBarcodeAPI = {
    // 1. Check Queue by Booking ID
    checkQueue: async (bookingId) => {
        try {
            const response = await axios.get(`${BASE_URL}/api/bpjs/barcode/check`, {
                params: { booking_id: bookingId },
            });

            // ✅ Ambil registration_no_client dari response API
            const registrationNo = response.data?.data?.detail?.registration_no_client || null;
            return { ...response.data, registrationNo };
        } catch (error) {
            console.error(`❌ Error checking queue for Booking ID ${bookingId}:`, error.response?.data || error.message);
            throw error;
        }
    },

    // 2. Insert Queue and Process Data by Booking ID
    processQueueAndInsertData: async (bookingId) => {
        try {
            const response = await axios.post(`${BASE_URL}/api/bpjs/barcode/insert`, null, {
                params: { booking_id: bookingId }
            });
            return response.data;
        } catch (error) {
            console.error(`❌ Error processing queue and inserting data for Booking ID ${bookingId}:`, error.response?.data || error.message);
            throw error;
        }
    },

    // 3. Switch Medicine to Pickup by Booking ID
    switchMedicineToPickup: async (bookingId) => {
        try {
            const response = await axios.post(`${BASE_URL}/api/bpjs/barcode/insert`, null, {
                params: { booking_id: bookingId }
            });
            return response.data;
        } catch (error) {
            console.error(`❌ Error switching medicine to pickup for Booking ID ${bookingId}:`, error.response?.data || error.message);
            throw error;
        }
    },
};

export default BPJSBarcodeAPI;
