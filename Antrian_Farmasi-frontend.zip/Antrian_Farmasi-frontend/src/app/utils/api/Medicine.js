//src\app\utils\api\Medicine.js
import axios from 'axios';

const BASE_URL = 'http://172.16.85.27:5000'; // Base URL API

const MedicineAPI = {
    // 1. Get All Medicine Tasks
    getAllMedicineTasks: async () => {
        try {
            const response = await axios.get(`${BASE_URL}/api/medicine-task/`);
            return response.data;
        } catch (error) {
            console.error('Error fetching all medicine tasks:', error);
            throw error;
        }
    },

    // 2. Get Medicine Task by Booking ID
    getMedicineTaskByBookingId: async (bookingId) => {
        try {
            const response = await axios.get(`${BASE_URL}/api/medicine-task/${bookingId}`);
            return response.data;
        } catch (error) {
            console.error(`Error fetching medicine task with Booking ID ${bookingId}:`, error);
            throw error;
        }
    },

    // 3. Create Medicine Task (Updated sesuai gambar)
    createMedicineTask: async (taskData) => {
        try {
            const response = await axios.post(`${BASE_URL}/api/medicine-task/`, taskData, {
                headers: { 'Content-Type': 'application/json' }
            });
            return response.data;
        } catch (error) {
            console.error('Error creating medicine task:', error);
            throw error;
        }
    },

    // 4. Update Medicine Task
    updateMedicineTask: async (bookingId, updatedData) => {
        try {
            const response = await axios.put(`${BASE_URL}/api/medicine-task/${bookingId}`, updatedData, {
                headers: { 'Content-Type': 'application/json' }
            });
            return response.data;
        } catch (error) {
            console.error(`Error updating medicine task with Booking ID ${bookingId}:`, error);
            throw error;
        }
    },

    // 5. Delete Medicine Task
    deleteMedicineTask: async (bookingId) => {
        try {
            const response = await axios.delete(`${BASE_URL}/api/medicine-task/${bookingId}`);
            return response.data;
        } catch (error) {
            console.error(`Error deleting medicine task with Booking ID ${bookingId}:`, error);
            throw error;
        }
    },
};

export default MedicineAPI;
