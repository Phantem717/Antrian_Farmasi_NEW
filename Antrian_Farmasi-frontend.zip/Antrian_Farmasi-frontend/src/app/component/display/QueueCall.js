import { useEffect, useState, useRef } from "react";
import VerificationAPI from "../../utils/api/Verification";
import MedicineAPI from "../../utils/api/Medicine";
import PickupAPI from "../../utils/api/Pickup";
import LoketAPI from "../../utils/api/Loket";

const QueueCall = () => {
  const [loading, setLoading] = useState(false);
  const [queueData, setQueueData] = useState(null);
  const [selectedLoket, setSelectedLoket] = useState(null);
  const lastProcessedQueue = useRef(null);

  // ✅ Ambil Loket Aktif dari API
  useEffect(() => {
    const fetchActiveLoket = async () => {
      try {
        const response = await LoketAPI.getAllLokets();
        console.log("📡 Loket yang diterima dari API:", response.data);
  
        const activeLoket = response.data.find(loket => loket.status.toLowerCase() === "active");
        if (activeLoket) {
          setSelectedLoket(activeLoket.loket_name);
          console.log("✅ Loket aktif ditemukan:", activeLoket.loket_name);
        } else {
          console.warn("⚠️ Tidak ada loket aktif.");
        }
      } catch (error) {
        console.error("❌ Error fetching active loket:", error);
      }
    };
  
    fetchActiveLoket();
  }, []);

  // ✅ Ambil Data Antrian dengan Semua Status yang Dibutuhkan
  useEffect(() => {
    if (!selectedLoket) return;
  
    const fetchQueues = async () => {
      setLoading(true);
      try {
        // Ambil semua data antrian dari API
        const [verificationRes, medicineRes, pickupRes] = await Promise.all([
          VerificationAPI.getAllVerificationTasks(),
          MedicineAPI.getAllMedicineTasks(),
          PickupAPI.getAllPickupTasks(),
        ]);

        console.log("📡 Data antrian dari API:", {
          verification: verificationRes.data,
          medicine: medicineRes.data,
          pickup: pickupRes.data
        });

        // Gabungkan semua antrian dan filter berdasarkan status yang diinginkan
        const validStatuses = [
          "called_verification", "called_medicine", "called_pickup_medicine",
          "recalled_verification", "recalled_medicine", "recalled_pickup_medicine"
        ];

        const allQueues = [...verificationRes.data, ...medicineRes.data, ...pickupRes.data]
          .filter(item => validStatuses.includes(item.status));

        console.log("✅ Antrian yang memiliki status yang sesuai:", allQueues);

        // Pilih antrian pertama yang belum diproses
        const nextQueue = allQueues.find(queue => lastProcessedQueue.current !== queue.queue_number);

        if (nextQueue) {
          lastProcessedQueue.current = nextQueue.queue_number;
          setQueueData({ queueNumber: nextQueue.queue_number, counter: selectedLoket });

          setTimeout(() => {
            announceQueue(nextQueue.queue_number, selectedLoket);
            setLoading(false);
          }, 1000);
        } else {
          setQueueData(null);
          setLoading(false);
        }
      } catch (error) {
        console.error("❌ Error fetching queue data:", error);
        setLoading(false);
      }
    };
  
    fetchQueues();
    const interval = setInterval(fetchQueues, 10000);
    return () => clearInterval(interval);
  }, [selectedLoket]);

  // ✅ Fungsi untuk pengumuman suara antrian
  const announceQueue = (queueNumber, counter) => {
    if (!queueNumber || !counter) {
      console.warn("⚠️ Nomor antrian atau loket tidak tersedia untuk diumumkan.");
      return;
    }

    if (!window.speechSynthesis) {
      console.warn("⚠️ Web Speech API is not supported in this browser.");
      return;
    }

    window.speechSynthesis.cancel();

    const spelledOutQueue = queueNumber.split("").filter(char => char !== "-").join("  ");
    const message = `Nomor antrian ${spelledOutQueue}, dipersilahkan menuju ke ${counter}`;

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = "id-ID";
    utterance.rate = 1;

    utterance.onend = () => setLoading(false);

    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="h-full bg-blue-700 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center">
      <h2 className="text-3xl font-bold text-white mb-4">Pemanggilan Antrian</h2>
      <p className="text-3xl font-bold text-white">Nomor Antrian</p>
      <div className="number text-6xl my-14" style={{ animation: "zoom-in-out 2s infinite" }}>
        {loading ? "Memuat..." : queueData ? queueData.queueNumber : "..."}
      </div>
      <p className="text-3xl font-bold text-white">
        {loading ? "Memuat..." : queueData ? queueData.counter : "Loket Tidak Diketahui"}
      </p>
      <style jsx>{`
        @keyframes zoom-in-out {
          0% { transform: scale(1); }
          50% { transform: scale(1.2); }
          100% { transform: scale(1); }
        }
      `}</style>
    </div>
  );
};

export default QueueCall;
