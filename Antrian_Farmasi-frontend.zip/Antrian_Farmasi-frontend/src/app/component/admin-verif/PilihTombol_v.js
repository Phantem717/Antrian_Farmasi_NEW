"use client";

import React from "react";
import { Box, Button } from "@mui/material";
import { updateButtonStatus } from "../../utils/api/Button";
import PharmacyAPI from "../../utils/api/Pharmacy";
import MedicineAPI from "../../utils/api/Medicine";
import Swal from "sweetalert2";

const PilihAksi = ({ selectedQueueIds = [], setSelectedQueueIds, selectedQueue }) => {  

  // ✅ Fungsi untuk memanggil banyak nomor antrian sekaligus
  const handleBulkCall = async () => {
    if (selectedQueueIds.length === 0) {
      Swal.fire({
        icon: "warning",
        title: "Pilih minimal satu nomor antrian!",
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 2000,
        timerProgressBar: true,
      });
      return;
    }

    try {
      console.log("📡 Memanggil nomor:", selectedQueueIds);

      await Promise.all(
        selectedQueueIds.map(async (booking_id) => {
          await updateButtonStatus(booking_id, "called_verification");
        })
      );

      Swal.fire({
        icon: "success",
        title: `Berhasil memanggil ${selectedQueueIds.length} nomor!`,
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 2000,
        timerProgressBar: true,
      });

      setSelectedQueueIds([]); // ✅ Reset pilihan setelah pemanggilan

    } catch (error) {
      console.error("❌ Error:", error);
      Swal.fire({
        icon: "error",
        title: "Gagal memanggil nomor!",
        text: error.message,
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
      });
    }
  };

  // ✅ Fungsi untuk update status antrian tunggal
  const handleBulkStatusUpdate = async (statusType) => {
    if (selectedQueueIds.length === 0) {
      Swal.fire({
        icon: "warning",
        title: "Pilih minimal satu nomor antrian!",
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 2000,
        timerProgressBar: true,
      });
      return;
    }
  
    try {
      console.log("📡 Memperbarui status untuk:", selectedQueueIds, "dengan status:", statusType);
  
      await Promise.all(
        selectedQueueIds.map(async (booking_id) => {
          await updateButtonStatus(booking_id, statusType);
        })
      );
  
      Swal.fire({
        icon: "success",
        title: `Berhasil memperbarui ${selectedQueueIds.length} antrian ke status ${statusType.replace("_", " ")}`,
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 2000,
        timerProgressBar: true,
      });
  
      setSelectedQueueIds([]); // ✅ Reset setelah update
  
    } catch (error) {
      console.error("❌ Error saat memperbarui status:", error);
      Swal.fire({
        icon: "error",
        title: "Gagal memperbarui status!",
        text: error.message,
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
      });
    }
  };

  const handleBulkPharmacyUpdate = async (medicineType) => {
    if (selectedQueueIds.length === 0) {
      Swal.fire({
        icon: "warning",
        title: "Pilih minimal satu nomor antrian!",
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 2000,
        timerProgressBar: true,
      });
      return;
    }
  
    try {
      console.log("📡 Memperbarui status RACIKAN/NON-RACIKAN untuk:", selectedQueueIds, "dengan tipe:", medicineType);
  
      await Promise.all(
        selectedQueueIds.map(async (booking_id) => {
          await PharmacyAPI.updatePharmacyTask(booking_id, {
            status: "waiting_medicine",
            medicine_type: medicineType,
          });
  
          await MedicineAPI.createMedicineTask({
            booking_id: booking_id,
            Executor: null,
            Executor_Names: null,
            status: "waiting_medicine",
          });
        })
      );
  
      Swal.fire({
        icon: "success",
        title: `Berhasil memperbarui ${selectedQueueIds.length} antrian ke status ${medicineType}`,
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 2500,
        timerProgressBar: true,
      });
  
      setSelectedQueueIds([]); // ✅ Reset setelah update
  
    } catch (error) {
      console.error("❌ Error saat memperbarui status RACIKAN/NON-RACIKAN:", error);
      Swal.fire({
        icon: "error",
        title: "Gagal memperbarui data!",
        text: error.message,
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
      });
    }
  };

  return (
    <Box
      sx={{
        display: "grid",
        gridTemplateColumns: "repeat(2, 1fr)",
        gap: "15px",
        maxWidth: "500px",
        margin: "auto",
      }}
    >
      {/* ✅ Tombol baru untuk memanggil banyak nomor sekaligus */}
      <Button
  variant="contained"
  sx={{ backgroundColor: "#4CAF50", color: "#ffffff", fontWeight: "bold", padding: "15px", height: "60px", fontSize: "1rem" }}
  onClick={handleBulkCall}
  disabled={selectedQueueIds.length === 0} // ⬅️ Pastikan hanya disable jika kosong
>
  PANGGIL {selectedQueueIds?.length || 0} NOMOR
</Button>


     {/* ✅ Pending banyak nomor */}
     <Button
      variant="contained"
      sx={{ backgroundColor: "#FF9800", color: "#ffffff", fontWeight: "bold", padding: "10px", height: "60px", fontSize: "1rem" }}
      onClick={() => handleBulkStatusUpdate("pending_verification")}
      disabled={selectedQueueIds.length === 0}
    >
      PENDING
    </Button>

     {/* ✅ Panggil ulang banyak nomor */}
     <Button
      variant="contained"
      sx={{ backgroundColor: "#FFD700", color: "#000000", fontWeight: "bold", padding: "12px", height: "60px", fontSize: "1rem", width: "100%" }}
      onClick={() => handleBulkStatusUpdate("recalled_verification")}
      disabled={selectedQueueIds.length === 0}
    >
      PANGGIL ULANG
    </Button>

        {/* ✅ Proses Verifikasi banyak nomor */}
    <Button
      variant="contained"
      sx={{ backgroundColor: "#1E88E5", color: "#ffffff", fontWeight: "bold", padding: "12px", height: "55px", fontSize: "0.95rem" }}
      onClick={() => handleBulkStatusUpdate("processed_verification")}
      disabled={selectedQueueIds.length === 0}
    >
      PROSES VERIFIKASI
    </Button>

      {/* ✅ Racikan banyak nomor */}
    <Button
      variant="contained"
      sx={{ backgroundColor: "#8E24AA", color: "#ffffff", fontWeight: "bold", padding: "12px", height: "55px", fontSize: "0.95rem" }}
      onClick={() => handleBulkPharmacyUpdate("Racikan")}
      disabled={selectedQueueIds.length === 0}
    >
      RACIKAN
    </Button>

     {/* ✅ Non-Racikan banyak nomor */}
     <Button
      variant="contained"
      sx={{ backgroundColor: "#FF4081", color: "#ffffff", fontWeight: "bold", padding: "12px", height: "55px", fontSize: "0.95rem" }}
      onClick={() => handleBulkPharmacyUpdate("Non - Racikan")}
      disabled={selectedQueueIds.length === 0}
    >
      NON - RACIKAN
    </Button>
  </Box>
  );
};

export default PilihAksi;
