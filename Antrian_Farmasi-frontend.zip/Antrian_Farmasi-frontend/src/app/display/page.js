'use client'
import QueueCall from '../component/display/QueueCall';
import ServingQueue from '../component/display/ServingQueue';
import MissQueue from '../component/display/MissQueue';
import NextQueue from '../component/display/NextQueue';
import InfoBar from '../component/display/InfoBar';
import MarqueeFooter from '../component/display/MarqueeFooter';

export default function Display() {
  return (
    <div className="bg-white h-screen flex flex-col p-4">
      {/* Kontainer Utama */}
      <div className="w-full mb-4">
        <InfoBar />
      </div>

      {/* Baris pertama: QueueCall, ServingQueue, dan MissedQueue */}
      <div className="flex flex-row gap-4 mb-4">
        <div className="flex-[1] basis-[40%]">
          <QueueCall />
        </div>
        <div className="flex-[1.2] basis-[20%]">
          <ServingQueue />
        </div>
        <div className="flex-[1.8] basis-[40%]">
          <MissQueue />
        </div>
      </div>

      {/* Baris kedua: NextQueue */}
      <div className="w-full mb-4">
        <NextQueue />
      </div>

      {/* Footer */}
      <MarqueeFooter />
    </div>
  );
}