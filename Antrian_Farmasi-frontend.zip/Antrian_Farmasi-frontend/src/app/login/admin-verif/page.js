"use client";

import React, { useState } from "react";
import { Layout } from "antd";
import Header from "@/app/component/Header";
import Footer from "@/app/component/Footer";
import DisplayAntrian from "@/app/component/admin-verif/DisplayAntrian_v";
import PilihAksi from "@/app/component/admin-verif/PilihTombol_v";
import DaftarAntrian from "@/app/component/admin-verif/DaftarAntrian_v";
import MovingText from "@/app/component/admin-verif/Movingtext_v";
import Sidebar from "@/app/component/Sidebar";

const { Content } = Layout;

export default function Admin() {
  const [collapsed, setCollapsed] = useState(false);
  const siderWidth = collapsed ? 80 : 300;
  
  const [selectedQueue, setSelectedQueue] = useState(null); // ⬅️ Untuk menyimpan nomor antrian terakhir yang dipilih
  const [selectedQueueIds, setSelectedQueueIds] = useState([]); // ⬅️ Untuk menyimpan banyak nomor antrian yang dipilih

  // ✅ Fungsi untuk menangani pemilihan antrian dari DaftarAntrian
  const onSelectQueue = (queueId) => {
    setSelectedQueue(queueId);
  };

  return (
    <Layout style={{ height: "100vh", overflow: "hidden" }}>
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

      <Layout
        style={{
          marginLeft: siderWidth,
          transition: "margin-left 0.3s ease-in-out",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Header />
        <MovingText />

        <Content
          style={{
            flex: 1,
            padding: "24px",
            background: "#fff",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div style={{ display: "flex", gap: "14px", flex: 1 }}>
            {/* Bagian Kiri - Display Antrian & Pilih Aksi */}
            <div
              style={{
                flex: "1",
                minWidth: "300px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
              }}
            >
              <DisplayAntrian
                queueNumber={selectedQueue ? `${selectedQueue.queue_number}` : "___"}
                loketNumber="Loket 1"
              />
              <PilihAksi
                selectedQueue={selectedQueue} // ⬅️ Tetap mengirim antrian terakhir yang dipilih
                selectedQueueIds={selectedQueueIds} // ⬅️ Mengirim banyak antrian yang dipilih
                setSelectedQueueIds={setSelectedQueueIds} // ⬅️ Memungkinkan perubahan dari PilihAksi
                onStatusUpdate={() => {}}
              />
            </div>

            {/* Bagian Kanan - Daftar Antrian */}
            <div style={{ flex: "2", overflowY: "auto", maxHeight: "100%" }}>
              <DaftarAntrian
                onSelectQueue={onSelectQueue}
                selectedQueueIds={selectedQueueIds} // ⬅️ Mengirim daftar nomor yang dipilih
                setSelectedQueueIds={setSelectedQueueIds} // ⬅️ Agar bisa diperbarui dari DaftarAntrian
              />
            </div>
          </div>
        </Content>

        <Footer />
      </Layout>
    </Layout>
  );
}
